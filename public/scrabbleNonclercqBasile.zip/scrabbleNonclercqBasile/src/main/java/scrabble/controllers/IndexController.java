package scrabble.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.validation.BindingResult;
// import javax.validation.Valid;
import java.util.List;
// import java.util.ArrayList;
import java.util.Map;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.web.bind.annotation.RequestMethod;
// import org.springframework.web.bind.annotation.RequestMapping;
//import app.Devinette;
// import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import javax.validation.Valid;
// import org.springframework.ui.ModelMap;
import scrabble.repositories.CoupsRepository;
import scrabble.repositories.PartieRepository;
import scrabble.entities.Partie;
import scrabble.entities.Coups;

@Controller
@SessionAttributes("partie")
public class IndexController {
  @Autowired
  JdbcTemplate jdbcTemplate;

  @Autowired 
  private CoupsRepository coupsRepository;
  
  @Autowired 
  private PartieRepository partieRepository;

  //sqli oo
  Partie partie = new Partie();
  String sql = "SELECT POINTS1, POINTS2, POINTS3 FROM COUPS WHERE PARTIE_ID='";
  String sql2 = "SELECT  SCORE1, SCORE2, SCORE3 FROM PARTIE WHERE PARTIE_ID=' ";
  // @ModelAttribute
  @GetMapping("/")
  public ModelAndView index(@Valid Partie partie, SessionStatus session) {
    partieRepository.save(partie);
    // List<Map<String, Object>>  scores = jdbcTemplate.queryForList(sql + partie.getId() + "'");
    var model = new ModelAndView();
    model.addObject("scores", jdbcTemplate.queryForList(sql + partie.getId() + "'"));
    model.addObject("scorestt", jdbcTemplate.queryForList(sql2 + partie.getId() + "'"));
    model.setViewName("index");

    return model;
  }

  @PostMapping("/")
  // public ModelAndView traitement( ) {
  public ModelAndView traitement(@Valid Partie partie, @Valid Coups coups, SessionStatus session){
    var model = new ModelAndView();

    partie.computeScore(coups);
    partie.nextRound();


    partieRepository.save(partie);
    coups.setPartie(partie);
    coupsRepository.save(coups);
    model.setViewName("redirect:/");
    return model;
  }

  @GetMapping("/nouveau")
    public String nouveau(SessionStatus session) {
      session.setComplete();
       return "redirect:/";
    } 

}
