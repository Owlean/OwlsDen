package scrabble.repositories;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import scrabble.entities.Partie;


public interface PartieRepository 
       extends CrudRepository<Partie, Long> {
}
