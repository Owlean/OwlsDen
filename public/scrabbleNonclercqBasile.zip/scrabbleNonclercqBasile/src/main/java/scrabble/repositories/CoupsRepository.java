package scrabble.repositories;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import scrabble.entities.Coups;


public interface CoupsRepository 
       extends CrudRepository<Coups, Long> {
}
