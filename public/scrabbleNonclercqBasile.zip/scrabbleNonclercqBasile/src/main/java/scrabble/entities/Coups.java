package scrabble.entities;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ElementCollection;
import javax.persistence.ManyToOne;
import javax.persistence.JoinColumn;

import lombok.Getter;
import lombok.Setter;


import java.util.List;
import java.util.ArrayList;


@Entity
@Table(name="coups") 
public class Coups {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="coups_id")
    @Getter @Setter 
    private Long id;

    @ManyToOne
    @JoinColumn(name = "partie_id")
    @Getter @Setter 
    private Partie partie;

    // @ElementCollection
    // @Getter @Setter 
    // private List<Integer> points;
    // @ElementCollection
    // @Getter @Setter 
    // private List<Boolean> scrabble;


    //Array but ...
    @Getter @Setter 
    private int points1;
    @Getter @Setter 
    private int points2;
    @Getter @Setter 
    private int points3;


    //Array but ...
    @Getter @Setter 
    private boolean scrabble1;
    @Getter @Setter 
    private boolean scrabble2;
    @Getter @Setter 
    private boolean scrabble3;

    public boolean getScrabble1(){
	return this.scrabble1;
    }

    public boolean getScrabble2(){
    	return this.scrabble2;
    }

    public boolean getScrabble3(){
    	return this.scrabble3;
    }

    //useless for now
    // @Getter @Setter 
    // private String[] letters;

    public Coups() {}

    // public void setPartie(Partie partie) {
    	// this.partie = partie;
    // }
}   
