package scrabble.entities;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;

@Entity
@Table(name="partie") 
public class Partie {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="partie_id")
    @Getter @Setter 
    private Long id;
    @Getter @Setter 
    private int playersNb;
    @Getter @Setter 
    private Coups[] coupsH;
    @Getter @Setter 
    private int round = 0;
    @Getter @Setter 
    public int score1 = 0;
    @Getter @Setter 
    public int score2 = 0;
    @Getter @Setter 
    public int score3 = 0;


    public Partie() {
        this.playersNb = 3;
    }

    public void addCoup(Coups coups) {
      coupsH[round] = coups;
      nextRound();
    }

    public void computeScore(Coups coups){
	setScore1((coups.getScrabble1() ? this.getScore1() +  50 + coups.getPoints1() : this.getScore1() + coups.getPoints1()));
	setScore2((coups.getScrabble2() ? this.getScore2() +  50 + coups.getPoints2(): this.getScore2() + coups.getPoints2()));
	setScore3((coups.getScrabble3() ? this.getScore3() +  50 + coups.getPoints3(): this.getScore3() + coups.getPoints3()));
    }

    public void nextRound(){
      this.round++;
    }
}   
